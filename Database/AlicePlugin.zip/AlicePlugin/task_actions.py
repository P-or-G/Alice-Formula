a = ['a=υ**2/R', 'a=ω**2R', 'a=Uωa=4π**2R/T**2', 'a=(υ-υ0)/t']
b = "υ=4, R=4"


def get_given(user_text):
    given = {}
    for item in user_text.split(', '):
        formula = item.split('=')
        given.update({formula[0]: formula[1]})
    return given


def solve_task(given, formulas):
    answer = "Недостаточно данных"
    for formula in formulas:
        formula = formula.split('=')[1]
        for key, value in given.items():
            formula = formula.replace(key, f"*{value}")
            formula = formula.replace('+*', '+').replace('-*', '-').replace('/*', '/').replace('***', '**')
            formula = formula.replace('(*', '(')

            if formula[:1] == '*':
                formula = formula[1:]

            try:
                answer = eval(formula)
            except:  # SyntaxError, NameError
                pass
    return answer
