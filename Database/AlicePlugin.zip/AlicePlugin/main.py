from task_actions import get_given, solve_task
from sql import get_similar_items

from flask import Flask, request
import logging
import json


app = Flask(__name__)
logging.basicConfig(level=logging.DEBUG)

FORMULAS = []


@app.route("/", methods=["POST"])
def main():
    global FORMULAS
    logging.info(request.json)

    response = {
        "version": request.json["version"],
        "session": request.json["session"],
        "response": {
            "end_session": False
        }
    }

    req = request.json
    if req["session"]["new"]:
        response["response"]["text"] = "Здравствуйте! Формулу чего вы ищите?"
    else:
        user_input = req["request"]["original_utterance"]
        if "=" in user_input:
            if FORMULAS:
                response["response"]["text"] = solve_task(get_given(user_input), FORMULAS)
            else:
                response["response"]["text"] = "Вы не указали формулу чего вы ищите."
        else:
            FORMULAS = []
            answer = "Вот формулы, которые я были найдены:\n"

            for item in get_similar_items(user_input.lower()):
                for formula in item[1].replace('[', '').replace(']', '').replace("'", "").split(',  '):
                    FORMULAS.append(formula)
                    answer += f"- {formula}\n"
            response["response"]["text"] = answer.replace('**', '^')
    return json.dumps(response)


if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)
