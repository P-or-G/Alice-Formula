import sqlite3

db = sqlite3.connect('formulas.db', check_same_thread=False)
cur = db.cursor()


def create_table():
    cur.execute('CREATE TABLE formulas(title, formula_types)')


def insert_item(item):
    cur.execute(f'INSERT INTO formulas VALUES {item}')
    db.commit()


def get_items():
    res = cur.execute(f'SELECT * FROM formulas')
    return res.fetchall()


def get_similar_items(user_text):
    res = cur.execute(f"SELECT * FROM formulas WHERE title LIKE '%_{user_text[1:-1]}_%' LIMIT 2")
    return res.fetchall()



