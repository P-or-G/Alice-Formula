from task_actions import get_given, solve_task
from sql import get_similar_items


FORMULAS = []
while True:
    user_input = input("введите ваше сообщение: ")
    if '=' in user_input:
        if FORMULAS:
            print(solve_task(get_given(user_input), FORMULAS))
        else:
            print('Вы не выбрали формулу')
    else:
        FORMULAS = []
        answer = "Вот формулы, которые я были найдены\n"
        for item in get_similar_items(user_input.lower()):
            for formula in item[1].replace('[', '').replace(']', '').replace("'", "").split(',  '):
                FORMULAS.append(formula)
                answer += f"- {formula}\n"
        print(answer)